#!/usr/local/bin/perl -w
use strict;

my $QUEUEMAX = 10;
my $MAPFILE = "topo.map";
my $NODEFILE = "nodes.map";
my $PACKETSIZEMAX = 2048;

package NSQueue;

sub new ($) {

	my $self = {};

	my $class = shift;
	$self->{'routeRef'} = shift;
	my $ratebps = shift;
	$self->{'rate'} = int($ratebps / 8);
	$self->{'latency'} = shift;
	$self->{'max'} = shift || $QUEUEMAX;

	$self->{'size'} = 0;

	$self->{'queue'} = [];

	bless ($self, $class);
	return $self;
}

sub enQ ($$) {

	my $self = shift;
	my $pkt = shift;
	my $vtime = shift;
	my $queue = $self->{'queue'};

	if (@$queue >= $self->{'max'}) {
		# drop the packet
		print "Dropping packet bound for ".$self->{'routeRef'}->{'id'}.": queue max is ".scalar(@$queue)."\n";
	} else {
		my $packSize = length($$pkt);
		my $txTime = $self->{'latency'} + ($packSize / $self->{'rate'}) + $vtime;
		if (@$queue > 0) {
#			$txTime += $queue->[0]->[1];
			$txTime += $self->{'size'} / $self->{'rate'};
		}
		print "Enqueued packet bound for ".$self->{'routeRef'}->{'id'}.", $txTime\n";
		push(@$queue, [$pkt, $txTime]);
		$self->{'size'} += $packSize;
	}
}

package NSRouter;

my $INFINITY = 65535;	# must be bigger than # of routers
my $MICRO = 1000000;

use IO::Socket::INET;
use Time::HiRes qw(gettimeofday);

sub vecToString ($) {
	my $ipaddr = shift;
	return vec($ipaddr, 0, 8).".".vec($ipaddr, 1, 8).".".vec($ipaddr, 2, 8).".".vec($ipaddr, 3, 8);
}

sub new ($) {

	my $self = {};
	my $class = shift;

	$self->{'id'} = shift;
	$self->{'routes'} = [];
	$self->{'nodes'} = shift;
	my $nodeKeyString = shift;
	$self->{'sock'} = IO::Socket::INET->new(Proto => 'udp', PeerAddr => $nodeKeyString) || die ("Couldn't open router send socket on $nodeKeyString:  $!");

	bless($self, $class);
	return $self;
}

sub addRoute ($$$$) {

	my $self = shift;
	my $routeRef = shift;
	my $rate = shift;
	my $latency = shift;
	my $max = shift;

#	push @{$self->{'routes'}}, new NSQueue($routeRef, $rate, $latency);
	$self->{'routes'}->[$routeRef->{'id'}] = new NSQueue($routeRef, $rate, $latency, $max);
	print "New queue added to ".$self->{'id'}.": $rate/$latency/max($max) to ".$routeRef->{'id'}."\n";
}

sub recv($$) {

	my $self = shift;
	my $pkt = shift;
	my $vtime = shift;

	my ($srcID, $srcIP, $destIP, $srcPort, $destPort) = unpack("NNNnn", $$pkt);
	my $dest = $self->{'nodes'}->{pack("Nn", $destIP, $destPort)};

	print "Router ".$self->{'id'}.": recv pkt at $vtime dest for ".vecToString(pack("N", $destIP)).":$destPort (node '$dest')\n";
	unless (defined($dest)) {
		print ("Received packet has no destination node, dropping...\n");
		return;
	}

	if ($dest == $self->{'id'}) {
		print "Sending packet from router ".$self->{'id'}." to ".vecToString(pack("N", $destIP)).":$destPort\n";
		$self->{'sock'}->send($$pkt);
	} else {
		my $queue = $self->getQ($dest);
		if (defined ($queue)) {
			$queue->enQ($pkt, $vtime);
		} else {
			die ("Unable to locate queue for packet with dest $dest");
		}
	}
}

sub getQ($) {
	my $self = shift;
	my $dest = shift;

	return $self->{'routingTable'}->[$dest];
}

sub run() {

	my $self = shift;
	my ($seconds, $microsec);

	my $wait = undef;

	for my $route (@{$self->{'routes'}}) {
		next unless defined($route);
		my $queue = $route->{'queue'};
		print "Router ".$self->{'id'}."->".$route->{'routeRef'}->{'id'}." run: ".scalar(@$queue)." items, head is ".$queue->[0]->[1]."\n" if (@$queue > 0);

#		while ((@$queue > 0) && ($queue->[0]->[1] >= time())) {

		# slightly imprecise subsecond counter
		($seconds, $microsec) = gettimeofday;
		while ((@$queue > 0) && ($queue->[0]->[1] <= ($seconds + ($microsec / $MICRO)))) {
			my ($pkt, $pTime) = @{shift(@$queue)};
			$route->{'size'} -= length($$pkt);
			($seconds, $microsec) = gettimeofday;
			$route->{'routeRef'}->recv($pkt, ($seconds + ($microsec / $MICRO)));
		}
		if (@$queue > 0) {
			my $packTime = $queue->[0]->[1] - ($seconds + ($microsec / $MICRO));
			if (defined($wait)) {
				$wait = $packTime if ($wait > $packTime);
			} else {
				$wait = $packTime;
			}	
		}
	}
	return $wait;
}

sub createTable($) {

	# creates routing table for all nodes using Dijkstra's
	# must be run before passing packets!

	my $self = shift;
	my $vertexes = shift;	# array of routers; index is router id

	$self->{'routingTable'} = [];

	# set up base state for all vertexes
	for my $vertex (@$vertexes) {
		next unless defined ($vertex);
		$vertex->{'done'} = 0;
		if ($vertex->{'id'} == $self->{'id'}) {
			$vertex->{'distance'} = 0;
		} else {
			$vertex->{'distance'} = $INFINITY;
		}
	}

	for my $vertex (@$vertexes) {
		next unless defined ($vertex);
		my $next;
		my $min = $INFINITY + 1;

		# figure out which vertex to visit next
		for my $vertexNext (@$vertexes) {
			next unless defined($vertexNext);
			if (!($vertexNext->{'done'}) && ($vertexNext->{'distance'} < $min)) {
				$next = $vertexNext;
				$min = $vertexNext->{'distance'};
			}
		}

		for my $edge (@{$next->{'routes'}}) {
			next unless defined ($edge);

# WEIGHT FUNCTION AS 1/{bitrate}
#			my $weight = $next->{'distance'} + (1/$edge->{'rate'});
# WEIGHT FUNCTION AS UNIT WEIGHT
			my $weight = $next->{'distance'} + 1;
			if ($edge->{'routeRef'}->{'distance'} > $weight) {
				$edge->{'routeRef'}->{'distance'} = $weight;
				$edge->{'routeRef'}->{'predecessor'} = $next;
			}
		}
		$next->{'done'}++;
	}
	for my $vertex (@$vertexes) {
		next unless defined ($vertex);
		next if ($vertex->{'id'} == $self->{'id'});
		my $startRoute = $vertex;
		while ($startRoute->{'predecessor'}->{'id'} != $self->{'id'}) {
			die ("route with no pred") unless (defined ($startRoute->{'predecessor'}));
			$startRoute = $startRoute->{'predecessor'};
		}

#		print "Router ".$vertex->{'id'}." accessible via ".$startRoute->{'id'}."\n";
		die("No queue for ".$vertex->{'id'}) unless defined ($self->{'routes'}->[$startRoute->{'id'}]);
		$self->{'routingTable'}->[$vertex->{'id'}] = $self->{'routes'}->[$startRoute->{'id'}];
	}
}

sub DESTROY() {

	my $self = shift;
	$self->{'sock'}->close() if (defined ($self->{'sock'}));
}

package main;

use FileHandle;
use Data::Dumper;
use Getopt::Std;
use IO::Socket;
use IO::Select;
use Time::HiRes qw(gettimeofday usleep);
use strict;

$| = 1;

sub main() {

	my %opts;
	getopts('p:m:n:i:', \%opts);
	my $port = $opts{'p'} || 30148;
	my $iaddr = $opts{'i'} || 'localhost';
	my $mapFile = $opts{'m'} || $MAPFILE;
	my $nodeFile = $opts{'n'} || $NODEFILE;

	my $fh;

	$fh = new FileHandle($nodeFile) || die ("Can't read $nodeFile");
	my %nodes;
	my %nodeKeys;

	for my $line (<$fh>) {
		next if ($line =~ m/^\#/);
		chomp($line);
		my ($node, $ip, $port) = split(/\s+/, $line);
		my $nodeKey = gethostbyname($ip).pack("n", $port);
		$nodes{$nodeKey} = $node;
		$nodeKeys{$node} = "$ip:$port";
	}
	$fh->close();

	$fh = new FileHandle($mapFile) || die ("Can't read $mapFile!"); 
	my @routers = ();

	for my $line (<$fh>) {
		next if ($line =~ m/^\#/);
		chomp($line);
		my ($from, $to, $rate, $latency, $queuemax) = split(/\s+/, $line);
		unless (defined($routers[$to])) {
			print "Creating new router $to\n";
			$routers[$to] = new NSRouter($to, \%nodes, $nodeKeys{$to});
		}
		unless (defined($routers[$from])) {
			print "Creating new router $from\n";
			$routers[$from] = new NSRouter($from, \%nodes, $nodeKeys{$from});
		}

		$routers[$to]->addRoute($routers[$from], $rate, $latency, $queuemax);
		$routers[$from]->addRoute($routers[$to], $rate, $latency, $queuemax);
	}
	$fh->close();

	for my $router (@routers) {
		next unless defined($router);
		$router->createTable(\@routers);
	}

	# ok, topology is set up, start listening for packets

	my $sleepSeconds = undef;

	my $sock = IO::Socket::INET->new(Proto => 'udp', LocalAddr => $iaddr, LocalPort => $port) || die ("Couldn't open socket:  $!");
	my $sel = new IO::Select($sock);

	my ($seconds, $microsec);
	my $systimesec;

	print "Listening on $port...\n";
	while (1) {
		($seconds, $microsec) = gettimeofday();
		$systimesec = sprintf("%d.%06d", $seconds, $microsec);
#		print "Time is $systimesec.\n";
		if (my ($selSock) = $sel->can_read($sleepSeconds)) {
#		if (my ($selSock) = $sel->can_read(0)) {
			my $pkt;
			$selSock->recv($pkt, $PACKETSIZEMAX);
			print "Got a packet\n";
			my($port, $ipaddr) = sockaddr_in($selSock->peername);

#			my ($srcID, $srcIP, $destIP, $srcPort, $destPort) = unpack("NNNnn", $pkt);
#			print "spiffy_header src: ".NSRouter::vecToString(pack("N", $srcIP))."\n";
#			print "spiffy_header dst: ".NSRouter::vecToString(pack("N", $destIP))."\n";
#			print "packet contents: ".substr($pkt, 16);

			my $nodeID = unpack("N", $pkt);
			print "spiffy_header nodeID: $nodeID\n";
			if (defined($routers[$nodeID])) {
#				print "Inserting packet at node $nodeID\n";
				($seconds, $microsec) = gettimeofday();
				$routers[$nodeID]->recv(\$pkt, ($seconds + ($microsec / $MICRO)));
			}
		}
		$sleepSeconds = undef;
		my $wait;
		for my $router (@routers) {
			if (defined ($router)) {
				$wait = $router->run();
#				print "router ".$router->{'id'}." waits $wait\n";
				if (defined($sleepSeconds)) {
					$sleepSeconds = $wait if (defined ($wait) && ($wait < $sleepSeconds));
				} else {
					$sleepSeconds = $wait;
				}
			}
		}
#		print "Sleeping for ".($sleepSeconds*$MICRO)." microseconds...";
#		usleep($sleepSeconds * $MICRO);
#		print "done.\n";
	}

}


main();
